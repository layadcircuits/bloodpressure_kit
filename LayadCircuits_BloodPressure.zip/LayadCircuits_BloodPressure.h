/***************************************************************************
 This is a library for the Blood Pressure sensor kit.
 
 This software is free provided that this notice is not removed and proper attribution 
 is accorded to Layad Circuits and its Author(s).
 Layad Circuits invests resources in producing free software. By purchasing Layad Circuits'
 products or utilizing its services, you support the continuing development of free software
 for all.
  
 Author(s): C.D.Malecdan for Layad Circuits Electronics Engineering
 Revision: 1.0 - 2017/04/13 - initial creation
 Layad Circuits Electronics Engineering Supplies and Services
 B314 Lopez Bldg., Session Rd. cor. Assumption Rd., Baguio City, Philippines
 www.layadcircuits.com
 general: info@layadcircuits.com
 sales: sales@layadcircuits.com
 +63-916-442-8565
 ***************************************************************************/

#ifndef LAYAD_CIRCUITS_BLOODPRESSURE_H
#define LAYAD_CIRCUITS_BLOODPRESSURE_H
#include "Arduino.h"
#include <SoftwareSerial.h>
class LayadCircuits_BloodPressure
{
public:
	LayadCircuits_BloodPressure(SoftwareSerial *);
	LayadCircuits_BloodPressure(HardwareSerial *);
    void begin(uint8_t startpin);
	bool isBPdataReady();
	uint16_t getSystole();
	uint16_t getDiastole();
	uint16_t getPulserate();
	void startCuffPump();

private:
	Stream *mySerial;
	SoftwareSerial *swSerial;
	HardwareSerial *hwSerial;
	uint8_t _pin_start;
	uint16_t _systole;
	uint16_t _diastole;
	uint16_t _pulserate;
	char _bp_data[16];
};
#endif