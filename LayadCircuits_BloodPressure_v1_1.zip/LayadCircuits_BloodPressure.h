/**	
	The use of this library requires proper attribution/acknowledgement of the Author and Layad Circuits.
	Library: LayadCircuits_BloodPressure 1.0	
	Revision: 1.0 - [16 Dec 2016] initial creation
	Author: C.Malecdan (chris@layadcircuits.com / +639164428565) for layad Circuits/ www.layadcircuits.com
**/

#ifndef LAYAD_CIRCUITS_LOODPRESSURE_H
#define LAYAD_CIRCUITS_LOODPRESSURE_H
#include "Arduino.h"
#include <SoftwareSerial.h>
class LayadCircuits_BloodPressure
{
public:
	LayadCircuits_BloodPressure(SoftwareSerial *);
	LayadCircuits_BloodPressure(HardwareSerial *);
    void begin(uint8_t startpin);
	bool isBPdataReady();
	uint16_t getSystole();
	uint16_t getDiastole();
	uint16_t getPulserate();
	void startCuffPump();

private:
	Stream *mySerial;
	SoftwareSerial *swSerial;
	HardwareSerial *hwSerial;
	uint8_t _pin_start;
	uint16_t _systole;
	uint16_t _diastole;
	uint16_t _pulserate;
	char _bp_data[16];
};
#endif