/**	
	The use of this library requires proper attribution/acknowledgement of the Author and Layad Circuits.
	Library: LayadCircuits_BloodPressure 1.0	
	Revision: 1.0 - [16 Dec 2016] initial creation
	Author: C.Malecdan (chris@layadcircuits.com / +639164428565) for layad Circuits/ www.layadcircuits.com
**/
#include "Arduino.h"
#include "LayadCircuits_BloodPressure.h"
#include <SoftwareSerial.h>

LayadCircuits_BloodPressure::LayadCircuits_BloodPressure(SoftwareSerial *ss) {

  hwSerial = NULL;
  swSerial = ss;
  mySerial = swSerial;
}

LayadCircuits_BloodPressure::LayadCircuits_BloodPressure(HardwareSerial *hs) {
  swSerial = NULL;
  hwSerial = hs;
  mySerial = hwSerial;
}

void LayadCircuits_BloodPressure::begin(uint8_t sp) {
  delay(1000);  // one second delay to let the sensor 'boot up'
  if (hwSerial) hwSerial->begin(9600);
  if (swSerial) swSerial->begin(9600);
  _pin_start = sp;
  pinMode(_pin_start,INPUT); // high Z
}

bool LayadCircuits_BloodPressure::isBPdataReady()
{
	uint8_t index = 0, ctr=0,j=0;
	char tempo[16]="";
	
	if(mySerial->available())
	{
		uint32_t t;
		t=millis();
		memset(_bp_data,0,16);
		while(millis() - t <= 100)
		{
			if(mySerial->available()) _bp_data[index++] = mySerial->read();
			if(index>=15) break;
		}
	}
	if(_bp_data[0] != 0) 
	{
		memset(tempo,0,16);
		j=0;
		for(byte i=0;i<16;i++)
		{ 
	        
			tempo[j++] = _bp_data[i];
			if(_bp_data[i] == ',')
			{
				ctr++;
				if(ctr==1)
				{
					_bp_data[i] = 0;
					_systole = atoi(tempo);
					memset(tempo,0,16);
					j=0;
				}
				else if(ctr==2)
				{
					_bp_data[i] = 0;
					_diastole = atoi(tempo);
					
				    memset(tempo,0,16);
					memcpy(tempo,&_bp_data[i+1],15-i);
					_pulserate = atoi(tempo);
	
					j=0;
					memset(tempo,0,16);
				}

				
			}
			
		}
		memset(_bp_data,0,16);
		return true;
	}
	else 
	{
		return false;
	}
}

uint16_t LayadCircuits_BloodPressure::getSystole()
{
	return _systole;	
}

uint16_t LayadCircuits_BloodPressure::getDiastole()
{
	return _diastole;	
}

uint16_t LayadCircuits_BloodPressure::getPulserate()
{
	return _pulserate;
}

void LayadCircuits_BloodPressure::startCuffPump()
{
  pinMode(_pin_start,OUTPUT);
  digitalWrite(_pin_start,LOW);
  delay(1);
  pinMode(_pin_start,INPUT);
}

